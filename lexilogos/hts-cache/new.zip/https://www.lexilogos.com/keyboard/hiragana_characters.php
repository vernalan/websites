<!doctype html>
<head>
<meta charset="utf-8">
<title>Test hiragana</title>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style>
.nih{ color:#CC0033; font-size:3em; font-family:MS UI Gothic; }
a.info{ text-decoration:none; cursor:help; }
a.info:hover { background-color:white;}
a.info .test-lettre{display: none}
a.info:hover .test-lettre{ display:block; position:relative; top:0.4em; font-size:1.5em; font-family:Arial; color:blue; }
</style>
<script>
if (parent.frames.length < 1) { 
document.location.href = 'hiragana_test.htm'; 
}
</script>
</head>
<body>
</span><div class="center">
<a href="javascript:location.reload()">Discover another character</a>
<div class="espd"></div>
<a class="info" href="#"><span class="nih">し</span><div class="test-lettre">shi</div></a>
</div>
</body>
</html>