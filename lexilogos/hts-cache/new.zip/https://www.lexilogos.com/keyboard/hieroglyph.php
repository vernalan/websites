<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Egyptian Hieroglyphs - Online Keyboard • Lexilogos</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Online Keyboard to type the Egyptian hieroglyphs from the Gardiner list">
<meta name="Keywords" content="hieroglyph,egyptian,keyboard">
<meta property="og:image" content="https://www.lexilogos.com/images/babel_bruegel.jpg">
<link rel="shortcut icon" href="../favicon.ico">
<style>
@font-face { font-family:Aegyptus; src:url(font/Aegyptus.otf); } 
.cadr { width:80%; color:#0000FF; font-family:Aegyptus; font-size:4em; }
.casemain { margin-left:10%; margin-right:10%; } 
.casetable { margin:auto; } 
.case { display: inline-block; padding-right:2em; padding-bottom:0.1em; text-align:center; }
a.chi { color:#CC0033; font-family:Aegyptus; font-size:3.3em; text-decoration:none; } 
a.chi:hover { color:#0000FF; background-color:#FFFF7D; text-decoration:none; }
.pin {color:#0000FF; font-family:Arial; } 

.tabl { margin:auto; }
.tabl tr { vertical-align:bottom }
.tabl td:nth-child(1) { text-align:center; padding-left:6em; padding-right:3em; }
.tabl td:nth-child(2) { text-align:left; }

@media screen and (max-width:960px) { 
.tabl td {display:inline-block;}
.tabl td:nth-child(1) { width:100%; text-align:left; padding-left:0; padding-right:0.5em; padding-bottom:0.7em;}
.tabl td:nth-child(2) { width:100%; }
.casemain { margin-left:0; margin-right:0; }
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script src="../code/hikb.js"></script>
<script src="../code/clipboard.js"></script>
<script src="../code/savee.js"></script>
<!-- GA -->
</head>
<body>
<div class="ca"><a href="../english/new.htm"><img src="../images/lexilogos_papagai.gif" class="imgpap" title="What's new?" alt="new"></a></div>
<div class="cb"><a href="../english/index.htm"><img src="../images/lexilogos_english.gif" class="imgloge" title="Online Dictionaries &gt; Index" alt="Lexilogos"></a></div>
<div class="cc"><a href="index.htm"><img src="../images/keyboard.gif" class="imgclae" alt="online keyboard" title="Index languages"></a><br>
<span class="kb-t">Egyptian Hieroglyphs</span></div>
<div class="cd"><a href="../english/communication.htm"><img src="../images/don_e.png" class="imgdone" title="Donate: Thank you!"></a><br>
<a href="../english/search.htm"><img src="../images/w_bouscateur.gif" class="imgbou" title="Search on Lexilogos &amp; on the web" alt="search"></a><br>
<a href="../clavier/hieroglyphe.php"><img src="../images/fra.gif" class="imgflag" alt="French" title="in French / en français"></a> 
</div>
<div class="esp"></div>
<div class="ce"> <a class="frp" href="egyptian_latin.htm">transliteration</a> &nbsp; <a class="frp" href="../english/hieroglyphs_dictionary.htm">Egyptian dictionary</a></div>
<div class="esp"></div>
<div class="center">
<form>
<select name="select" onChange="window.location=this.options[this.selectedIndex].value">
<option value="index.htm" selected>select a language</option>
<option value="ipa.htm">International Phonetic Alphabet</option>
<option value="latin_alphabet.htm">Latin script</option>
<option value="diacritics.htm">Diacritics</option>
<option value="albanian.htm">Albanian</option>
<option value="amharic.htm">Amharic</option>
<option value="arabic.htm">Arabic</option>
<option value="arabic_latin.htm">Arabic (Latin)</option>
<option value="arabian_north.htm">Arabian (Old North)</option>
<option value="arabian_south.htm">Arabian (Old South)</option>
<option value="armenian.htm">Armenian</option>
<option value="armenian_western.htm">Armenian (Western)</option>
<option value="azeri.htm">Azerbaijani</option>
<option value="bashkir.htm">Bashkir</option>
<option value="baybayin.htm">Baybayin</option>
<option value="belarusian.htm">Belarusian</option>
<option value="bengali.htm">Bengali</option>
<option value="tamazight_latin.htm">Berber (Latin)</option>
<option value="tamazight.htm">Berber (Tifinagh)</option>
<option value="bosnian.htm">Bosnian</option>
<option value="brahmi.htm">Brahmi</option>
<option value="bulgarian.htm">Bulgarian</option>
<option value="burmese.htm">Burmese</option>
<option value="catalan.htm">Catalan</option>
<option value="chechen.htm">Chechen</option>
<option value="tsalagi.htm">Cherokee</option>
<option value="chinese.php">Chinese</option>
<option value="chinese_pinyin.htm">Chinese Pinyin</option>
<option value="coptic.htm">Coptic</option>
<option value="croatian.htm">Croatian</option>
<option value="czech.htm">Czech</option>
<option value="danish.htm">Danish</option>
<option value="dutch.htm">Dutch</option>
<option value="hieroglyph.php">Egyptian (Ancient) Hieroglyphs</option>
<option value="egyptian_latin.htm">Egyptian (Ancient) (Latin)</option>
<option value="english.htm">English (Old)</option>
<option value="esperanto.htm">Esperanto</option>
<option value="estonian.htm">Estonian</option>
<option value="faroese.htm">Faroese</option>
<option value="finnish.htm">Finnish</option>
<option value="french.htm">French</option>
<option value="gaelic_irish.htm">Gaelic Irish</option>
<option value="gaelic_scottish.htm">Gaelic Scottish</option>
<option value="georgian.htm">Georgian</option>
<option value="german.htm">German</option>
<option value="glagolitic.htm">Glagolitic</option>
<option value="gothic.htm">Gothic</option>
<option value="grantha.htm">Grantha</option>
<option value="greek_ancient.htm">Greek (Ancient)</option>
<option value="greek_modern.htm">Greek (Modern)</option>
<option value="greek_latin.htm">Greek (Latin)</option>
<option value="gujarati.htm">Gujarati</option>
<option value="hausa.htm">Hausa</option>
<option value="hawaiian.htm">Hawaiian</option>
<option value="hebrew.htm">Hebrew</option>
<option value="hebrew_latin.htm">Hebrew (Latin)</option>
<option value="devanagari.htm">Hindi</option>
<option value="hungarian.htm">Hungarian</option>
<option value="icelandic.htm">Icelandic</option>
<option value="indo_european.htm">Indo-European</option>
<option value="ingush.htm">Ingush</option>
<option value="inuktitut.htm">Inuktitut</option>
<option value="italian.htm">Italian</option>
<option value="japanese.php">Japanese</option>
<option value="hiragana.htm">Japanese Hiragana</option>
<option value="katakana.htm">Japanese Katakana</option>
<option value="jawi.htm">Jawi</option>
<option value="kannada.htm">Kannada</option>
<option value="kashmiri.htm">Kashmiri</option>
<option value="kashubian.htm">Kashubian</option>
<option value="kazakh.htm">Kazakh</option>
<option value="khmer.htm">Khmer</option>
<option value="khowar.htm">Khowar</option>
<option value="korean.htm">Korean</option>
<option value="kurdish.htm">Kurdish</option>
<option value="kyrgyz.htm">Kyrgyz</option>
<option value="lao.htm">Lao</option>
<option value="latin.htm">Latin</option>
<option value="latvian.htm">Latvian</option>
<option value="lingala.htm">Lingala</option>
<option value="lithuanian.htm">Lithuanian</option>
<option value="macedonian.htm">Macedonian</option>
<option value="malayalam.htm">Malayalam</option>
<option value="thaana.htm">Maldivian</option>
<option value="maltese.htm">Maltese</option>
<option value="maori.htm">Maori</option>
<option value="meitei.htm">Meitei</option>
<option value="mongolian.htm">Mongolian</option>
<option value="montenegrin.htm">Montenegrin</option>
<option value="norwegian.htm">Norwegian</option>
<option value="odia.htm">Oriya</option>
<option value="pashto.htm">Pashto</option>
<option value="persian.htm">Persian</option>
<option value="persian_old.htm">Persian (Old)</option>
<option value="phoenician.htm">Phoenician</option>
<option value="polish.htm">Polish</option>
<option value="portuguese.htm">Portuguese</option>
<option value="gurmukhi.htm">Punjabi</option>
<option value="romanian.htm">Romanian</option>
<option value="futhark.htm">Runes Futhark</option>
<option value="futhark_old.htm">Runes Elder Futhark</option>
<option value="russian.htm">Russian</option>
<option value="samaritan.htm">Samaritan</option>
<option value="sanskrit_devanagari.htm">Sanskrit Devanagari</option>
<option value="sanskrit_devanagari_uttara.htm">Sanskrit Devanagari Uttara</option>
<option value="sanskrit_vedic.htm">Sanskrit Vedic</option>
<option value="sanskrit_latin.htm">Sanskrit (Latin)</option>
<option value="serbian.htm">Serbian</option>
<option value="serbian_latin.htm">Serbian (Latin)</option>
<option value="sindhi.htm">Sindhi</option>
<option value="sinhala.htm">Sinhala</option>
<option value="slovak.htm">Slovak</option>
<option value="slovenian.htm">Slovenian</option>
<option value="osmanya.htm">Somali Osmanya</option>
<option value="sorani.htm">Sorani</option>
<option value="spanish.htm">Spanish</option>
<option value="swedish.htm">Swedish</option>
<option value="syriac.htm">Syriac</option>
<option value="syriac_latin.htm">Syriac (Latin)</option>
<option value="tajik.htm">Tajik</option>
<option value="tamil.htm">Tamil</option>
<option value="tatar.htm">Tatar</option>
<option value="telugu.htm">Telugu</option>
<option value="thai.htm">Thai</option>
<option value="tibetan.htm">Tibetan</option>
<option value="tigrinya.htm">Tigrinya</option>
<option value="torwali.htm">Torwali</option>
<option value="turkish.htm">Turkish</option>
<option value="ottoman_turkish.htm">Turkish (Ottoman)</option>
<option value="turkmen.htm">Turkmen</option>
<option value="ukrainian.htm">Ukrainian</option>
<option value="urdu.htm">Urdu</option>
<option value="uyghur.htm">Uyghur</option>
<option value="uzbek.htm">Uzbek</option>
<option value="vietnamese.htm">Vietnamese</option>
<option value="welsh.htm">Welsh</option>
<option value="wolof.htm">Wolof</option>
<option value="yiddish.htm">Yiddish</option>
<option value="yoruba.htm">Yoruba</option>
</select>
</form>
<br>
<form name="conversion" action="" method="post">
<div class="delc">
<br>
 
<input type="button" class="eff" title="clear" onClick="effacer();conversion.saisie.focus()" value="">
</div>
<textarea spellcheck="false" name="saisie" id="bar" rows="3" class="cadr"></textarea>
<br>
<br>
<input type="button" class="bf" data-clipboard-action="copy" data-clipboard-target="#bar" value="copy">
<script>
var clipboard = new Clipboard('.bf');
clipboard.on('success', function(e) {
console.log(e); 
});
clipboard.on('error', function(e) {
console.log(e);
});
</script>
<input type="button" class="bf" onClick="save()" value="save">
<input type="button" class="bf" onClick="kb(' ')" value="space"><input type="button" class="bf" onClick="conversion.saisie.rows=3;conversion.q.focus();" value="small frame"><input type="button" class="bf" onClick="conversion.saisie.rows=21;conversion.q.focus();" value="large frame">
<div class="espc"></div>
<table class="tabl">
<tr>
<td> <p class="k">Type a code</p>
<input autofocus name='q' size='30' onkeyup='verif()' maxlength='10'>
</td>
<td>
<select name="gardiner" onChange="submit()">
<option value="">or select a Gardiner list</option>
<option value="A">A - Man</option>
<option value="B">B - Woman</option>
<option value="C">C - Gods</option>
<option value="D">D - Parts of human body</option>
<option value="E">E - Mammals</option>
<option value="F">F - Parts of mammals</option>
<option value="G">G - Birds</option>
<option value="H">H - Parts of birds</option>
<option value="I">I - Reptiles, ammphibious animals</option>
<option value="K">K - Fishes</option>
<option value="L">L - Invertebrates, lesser animals</option>
<option value="M">M - Trees, plants</option>
<option value="N">N - Sky, earh, water</option>
<option value="O">O - Buildings</option>
<option value="P">P - Ships</option>
<option value="Q">Q - Domestics and funerary furniture</option>
<option value="R">R - Temple furniture, sacred emblemss</option>
<option value="S">S - Crowns, dress, staves</option>
<option value="T">T - Warfare, hunting</option>
<option value="U">U - Agriculture, crafts, professions</option>
<option value="V">V - Rope, fiber, baskets, bags</option>
<option value="W">W - Vessels</option>
<option value="X">X - Loaves, cakes</option>
<option value="Y">Y - Writings, games, music</option>
<option value="Z">Z - Geometrical figures</option>
<option value="AA">AA - unclassified</option>
<option value="NL">Lower-Egypt Nomes</option>
<option value="NU">Upper-Egypt Nomes</option>
</select> 
</td>
</tr>
</table>
</form>
<div class="espc"></div>

</div>
<div class="espb"></div>
<div class="pa"> <b>Instructions</b>: 
<p>1) Type a Gardiner code (1 consonant + number) example: A1</p>
<p><span class="espr"></span>or a code from the <i>Manuel de codage for hieroglyphic texts</i>, example: zzmt</p>
<p>2) Type a space (or Enter) </p>
<p>3) Select the Egyptian hieroglyph (click with the mouse) </p>
<br>
<p>Download &amp; install the font <a href="font/Aegyptus.otf">Aegyptus</a> </p>
<div class="espd"></div>
<b>Note</b>: 
<p>This keyboard presents more than 5000 hieroglyphs, including the official unicodes &amp; those from the book <a href="https://www.academia.edu/4180892" target="_blank" class="ext i">Hieroglyphica</a>.</p>
<div class="espc"></div>
<p>Copy [Ctrl]+[C] &amp; Paste [Ctrl]+[V] on an image with a freeware like <i>Paint</i> (by selecting the font <i>Aegyptus</i>) <br>
then possibly modify the place of the hieroglyphs (by presenting them, in certain cases, one on the other)</p>



</div>
<div class="espa"></div>
<p class="pp"><span class="ji">&#x2192;</span> <a href="egyptian_latin.htm">Latin Egyptian keyboard</a> for transliteration </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="../english/hieroglyphs_dictionary.htm">Egyptian language</a>: dictionary, grammar, texts </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="../english/coptic_dictionary.htm">Coptic language</a> </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="coptic.htm">Coptic keyboard</a> </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="index.htm">Multilingual keyboard</a>: index </p>

<div class="espb"></div>
<ul class="nav">
<li><a href="../english/contact.php" title="Share your feedback"><img src="../images/w_enveloppe.gif" class="img-0" alt="contact"></a>
<a class="pie" href="../english/contact.php">Contact</a></li>
<li><a href="../english/search.htm" title="Search on Lexilogos &amp; on the web"><img src="../images/w_bouscateur.gif" class="img-0" alt="search"></a> 
<a class="pie" href="../english/search.htm">Search</a></li>
<li><a title="updates" class="new" href="../english/new.htm">NEW</a>
<a class="pie" href="../english/new.htm">What's new?</a> </li>
<li><a href="../english/index.htm" title="Homepage"><img src="../images/w_accueil.gif" class="img-0" alt="homepage"></a>
<a class="pie" href="../english/index.htm">Homepage</a></li>
<li><a href="../english/lexilogos_introduction.htm" title="Introduction"><img src="../images/w_q.gif" class="img-0" alt="introduction"></a>
<a class="pie" href="../english/lexilogos_introduction.htm">Introduction</a></li>
<li><a href="../english/communication.htm" title="Support Lexilogos!"><img src="../images/w_cor.gif" class="img-0" alt="support"></a>
<a class="pie" href="../english/communication.htm">Donation</a></li>
</ul>
<div class="esp"></div>
<div class="center"><a class="co" href="../contact.php">Xavier Nègre &nbsp; © Lexilogos 2002-2025</a></div>
<div class="espd"></div>
</body>
</html>
