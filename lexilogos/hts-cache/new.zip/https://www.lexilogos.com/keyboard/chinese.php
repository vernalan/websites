<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Chinese Keyboard Online LEXILOGOS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Online Chinese Keyboard to type 9000 Chinese characters with the Latin alphabet (pinyin)">
<meta name="Keywords" content="chinese,keyboard,character">
<meta property="og:image" content="https://www.lexilogos.com/images/babel_bruegel.jpg">
<link rel="shortcut icon" href="../favicon.ico"> 
<style>
.cadr { width:80%; color:#0000FF; font-family:sans-serif; font-size:1.7em; padding:3px; }
.bt, .bt:visited {text-decoration:none; cursor:pointer; font-size:1em; font-family:sans-serif; color:#CC0033;}
.bt:hover {color:#0000FF; }
.casemain { margin-left:10%; margin-right:10%; } 
.casetable { margin:auto; } 
.case { display: inline-block; padding-left:1em; padding-right:1em; padding-bottom:1em; text-align:center;}
a.chi { color:#CC0033; text-decoration:none; font-size:2em; font-family:sans-serif; } 
a.chi:hover { color:#0000FF; background-color:#FFFF7D; text-decoration:none; font-size:2em; font-family:sans-serif; }
.num {color:#666666; font-family:sans-serif; } 
.pin {color:#0000FF; font-family:sans-serif; } 

.tabl { margin:auto; }
.tabl tr { vertical-align:bottom; }
.tabl td:nth-child(1) { text-align:left; padding-right:6em; }
.tabl td:nth-child(2) { text-align:center; }

@media screen and (max-width:960px) { 
.tabl td {display:inline-block;}
.tabl td:nth-child(1) { padding-right:0.5em;}
.tabl td:nth-child(2) { text-align:left; }
.casemain { margin-left:0; margin-right:0; }
</style> 
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script src="../code/zhkb.js"></script>
<script src="../code/clipboard.js"></script>
<script src="../code/savee.js"></script>
<!-- GA -->
</head>
<body onLoad="conversion.saisie.focus()">
<div class="ca"><a href="../english/new.htm"><img src="../images/lexilogos_papagai.gif" class="imgpap" title="What's new?" alt="new"></a></div>
<div class="cb"><a href="../english/index.htm"><img src="../images/lexilogos_english.gif" class="imgloge" title="Online Dictionaries &gt; Index" alt="Lexilogos"></a></div>
<div class="cc"><a href="index.htm"><img src="../images/keyboard.gif" class="imgclae" alt="online keyboard" title="Index languages"></a><br>
<span class="kb-t">Chinese</span> &nbsp; <span class="kb-niho">中文</span></div>
<div class="cd"><a href="../english/communication.htm"><img src="../images/don_e.png" class="imgdone" title="Donate: Thank you!"></a><br>
<a href="../english/search.htm"><img src="../images/w_bouscateur.gif" class="imgbou" title="Search on Lexilogos &amp; on the web" alt="search"></a><br>
<a href="../clavier/zhongwen.php"><img src="../images/fra.gif" class="imgflag" alt="French" title="in French / en français"></a> 
</div>
<div class="esp"></div>
<div class="ce"><a class="frp" href="../english/chinese_dictionary.htm">Chinese dictionary</a></div>
<div class="esp"></div>
<div class="center"> 
<form>
<select name="select" onChange="window.location=this.options[this.selectedIndex].value">
<option value="index.htm" selected>select a language</option>
<option value="ipa.htm">International Phonetic Alphabet</option>
<option value="latin_alphabet.htm">Latin script</option>
<option value="diacritics.htm">Diacritics</option>
<option value="albanian.htm">Albanian</option>
<option value="amharic.htm">Amharic</option>
<option value="arabic.htm">Arabic</option>
<option value="arabic_latin.htm">Arabic (Latin)</option>
<option value="arabian_north.htm">Arabian (Old North)</option>
<option value="arabian_south.htm">Arabian (Old South)</option>
<option value="armenian.htm">Armenian</option>
<option value="armenian_western.htm">Armenian (Western)</option>
<option value="azeri.htm">Azerbaijani</option>
<option value="bashkir.htm">Bashkir</option>
<option value="baybayin.htm">Baybayin</option>
<option value="belarusian.htm">Belarusian</option>
<option value="bengali.htm">Bengali</option>
<option value="tamazight_latin.htm">Berber (Latin)</option>
<option value="tamazight.htm">Berber (Tifinagh)</option>
<option value="bosnian.htm">Bosnian</option>
<option value="brahmi.htm">Brahmi</option>
<option value="bulgarian.htm">Bulgarian</option>
<option value="burmese.htm">Burmese</option>
<option value="catalan.htm">Catalan</option>
<option value="chechen.htm">Chechen</option>
<option value="tsalagi.htm">Cherokee</option>
<option value="chinese.php">Chinese</option>
<option value="chinese_pinyin.htm">Chinese Pinyin</option>
<option value="coptic.htm">Coptic</option>
<option value="croatian.htm">Croatian</option>
<option value="czech.htm">Czech</option>
<option value="danish.htm">Danish</option>
<option value="dutch.htm">Dutch</option>
<option value="hieroglyph.php">Egyptian (Ancient) Hieroglyphs</option>
<option value="egyptian_latin.htm">Egyptian (Ancient) (Latin)</option>
<option value="english.htm">English (Old)</option>
<option value="esperanto.htm">Esperanto</option>
<option value="estonian.htm">Estonian</option>
<option value="faroese.htm">Faroese</option>
<option value="finnish.htm">Finnish</option>
<option value="french.htm">French</option>
<option value="gaelic_irish.htm">Gaelic Irish</option>
<option value="gaelic_scottish.htm">Gaelic Scottish</option>
<option value="georgian.htm">Georgian</option>
<option value="german.htm">German</option>
<option value="glagolitic.htm">Glagolitic</option>
<option value="gothic.htm">Gothic</option>
<option value="grantha.htm">Grantha</option>
<option value="greek_ancient.htm">Greek (Ancient)</option>
<option value="greek_modern.htm">Greek (Modern)</option>
<option value="greek_latin.htm">Greek (Latin)</option>
<option value="gujarati.htm">Gujarati</option>
<option value="hausa.htm">Hausa</option>
<option value="hawaiian.htm">Hawaiian</option>
<option value="hebrew.htm">Hebrew</option>
<option value="hebrew_latin.htm">Hebrew (Latin)</option>
<option value="devanagari.htm">Hindi</option>
<option value="hungarian.htm">Hungarian</option>
<option value="icelandic.htm">Icelandic</option>
<option value="indo_european.htm">Indo-European</option>
<option value="ingush.htm">Ingush</option>
<option value="inuktitut.htm">Inuktitut</option>
<option value="italian.htm">Italian</option>
<option value="japanese.php">Japanese</option>
<option value="hiragana.htm">Japanese Hiragana</option>
<option value="katakana.htm">Japanese Katakana</option>
<option value="jawi.htm">Jawi</option>
<option value="kannada.htm">Kannada</option>
<option value="kashmiri.htm">Kashmiri</option>
<option value="kashubian.htm">Kashubian</option>
<option value="kazakh.htm">Kazakh</option>
<option value="khmer.htm">Khmer</option>
<option value="khowar.htm">Khowar</option>
<option value="korean.htm">Korean</option>
<option value="kurdish.htm">Kurdish</option>
<option value="kyrgyz.htm">Kyrgyz</option>
<option value="lao.htm">Lao</option>
<option value="latin.htm">Latin</option>
<option value="latvian.htm">Latvian</option>
<option value="lingala.htm">Lingala</option>
<option value="lithuanian.htm">Lithuanian</option>
<option value="macedonian.htm">Macedonian</option>
<option value="malayalam.htm">Malayalam</option>
<option value="thaana.htm">Maldivian</option>
<option value="maltese.htm">Maltese</option>
<option value="maori.htm">Maori</option>
<option value="meitei.htm">Meitei</option>
<option value="mongolian.htm">Mongolian</option>
<option value="montenegrin.htm">Montenegrin</option>
<option value="norwegian.htm">Norwegian</option>
<option value="odia.htm">Oriya</option>
<option value="pashto.htm">Pashto</option>
<option value="persian.htm">Persian</option>
<option value="persian_old.htm">Persian (Old)</option>
<option value="phoenician.htm">Phoenician</option>
<option value="polish.htm">Polish</option>
<option value="portuguese.htm">Portuguese</option>
<option value="gurmukhi.htm">Punjabi</option>
<option value="romanian.htm">Romanian</option>
<option value="futhark.htm">Runes Futhark</option>
<option value="futhark_old.htm">Runes Elder Futhark</option>
<option value="russian.htm">Russian</option>
<option value="samaritan.htm">Samaritan</option>
<option value="sanskrit_devanagari.htm">Sanskrit Devanagari</option>
<option value="sanskrit_devanagari_uttara.htm">Sanskrit Devanagari Uttara</option>
<option value="sanskrit_vedic.htm">Sanskrit Vedic</option>
<option value="sanskrit_latin.htm">Sanskrit (Latin)</option>
<option value="serbian.htm">Serbian</option>
<option value="serbian_latin.htm">Serbian (Latin)</option>
<option value="sindhi.htm">Sindhi</option>
<option value="sinhala.htm">Sinhala</option>
<option value="slovak.htm">Slovak</option>
<option value="slovenian.htm">Slovenian</option>
<option value="osmanya.htm">Somali Osmanya</option>
<option value="sorani.htm">Sorani</option>
<option value="spanish.htm">Spanish</option>
<option value="swedish.htm">Swedish</option>
<option value="syriac.htm">Syriac</option>
<option value="syriac_latin.htm">Syriac (Latin)</option>
<option value="tajik.htm">Tajik</option>
<option value="tamil.htm">Tamil</option>
<option value="tatar.htm">Tatar</option>
<option value="telugu.htm">Telugu</option>
<option value="thai.htm">Thai</option>
<option value="tibetan.htm">Tibetan</option>
<option value="tigrinya.htm">Tigrinya</option>
<option value="torwali.htm">Torwali</option>
<option value="turkish.htm">Turkish</option>
<option value="ottoman_turkish.htm">Turkish (Ottoman)</option>
<option value="turkmen.htm">Turkmen</option>
<option value="ukrainian.htm">Ukrainian</option>
<option value="urdu.htm">Urdu</option>
<option value="uyghur.htm">Uyghur</option>
<option value="uzbek.htm">Uzbek</option>
<option value="vietnamese.htm">Vietnamese</option>
<option value="welsh.htm">Welsh</option>
<option value="wolof.htm">Wolof</option>
<option value="yiddish.htm">Yiddish</option>
<option value="yoruba.htm">Yoruba</option>
</select>
</form>
<br>
<form name="conversion" action="" method="post">
<div class="delc">
<br>
 
<input type="button" class="eff" title="clear" onClick="effacer();conversion.saisie.focus()" value="">
</div>
<textarea spellcheck="false" name="saisie" id="bar" onKeyUp="transcrire()" rows="4" class="cadr"></textarea>
<br>
<br>
<input type="button" class="bf" data-clipboard-action="copy" data-clipboard-target="#bar" value="copy">
<script>
var clipboard = new Clipboard('.bf');
clipboard.on('success', function(e) {
console.log(e); 
});
clipboard.on('error', function(e) {
console.log(e);
});
</script>
<input type="button" class="bf" onClick="save()" value="save">
<input type="button" class="bf" onClick="kb(' ')" value="space"><input type="button" class="bf" onClick="conversion.saisie.rows=4;conversion.q.focus();" value="small frame"><input type="button" class="bf" onClick="conversion.saisie.rows=40;conversion.q.focus();" value="large frame">
<div class="espd"></div>
<table class="tabl">
<tr>
<td><input type="button" class="bt" onclick="kb('。')" value="。" title="句号 jùhào">
<input type="button" class="bt" onclick="kb('、')" value="、" title="顿号 dùnhào">
<input type="button" class="bt" onclick="kb('·')" value="·" title="间隔号 jiàngéhào"></td>
<td> <p class="k">Type a syllable in pinyin</p>
<input name='q' onkeyup='verif()' size='30' maxlength='10'>
</td>
</tr>
</table>
</form>


</div>
<div class="espb"></div>
<div class="pa"><b>Instructions</b>
<p>1) Type a syllable in pinyin (with the numerals or tone marks). </p>
<p>2) Type a space key (or <i>Submit</i>). </p>
<p>3) Select the Chinese character with a mouse click </p>
<p class="ppc">or with the tab key <img src="../images/touche_tabulation.gif" class="img-mid" alt="tabulation"> &nbsp; then submit). </p>
<br>
<p>For the character ü, type [ü] or [u:] or [v] </p>
<br>
<p>The characters are classified in order of frequency. </p>
<p>More than 9&#x202F;000 Chinese characters can be typed with the Chinese keyboard. </p>
<br>
Copy [Ctrl]+[C] &amp; Paste [Ctrl]+[V] 
</div>
<div class="espa"></div>
<p class="pp"><span class="ji">&#x2192;</span> <a href="chinese_conversion.htm">Chinese conversion</a> simplified &lt;&gt; traditional characters </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="../clavier/zhongwen.htm">Chinese keyboard</a>: 20&#x202F;000 characters (simplified &amp; traditionals) classified by radicals </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="pinyin_conversion.htm">Pinyin conversion</a> numerals &lt;&gt; tone marks </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="chinese_pinyin.htm">Pinyin keyboard</a> to type a Chinese text with the Latin alphabet (tone marks) </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="../english/chinese_dictionary.htm">Chinese language</a>: dictionary &amp; grammar </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="index.htm">Multilingual keyboard</a>: index </p>

<div class="espb"></div>
<ul class="nav">
<li><a href="../english/contact.php" title="Share your feedback"><img src="../images/w_enveloppe.gif" class="img-0" alt="contact"></a>
<a class="pie" href="../english/contact.php">Contact</a></li>
<li><a href="../english/search.htm" title="Search on Lexilogos &amp; on the web"><img src="../images/w_bouscateur.gif" class="img-0" alt="search"></a> 
<a class="pie" href="../english/search.htm">Search</a></li>
<li><a title="updates" class="new" href="../english/new.htm">NEW</a>
<a class="pie" href="../english/new.htm">What's new?</a> </li>
<li><a href="../english/index.htm" title="Homepage"><img src="../images/w_accueil.gif" class="img-0" alt="homepage"></a>
<a class="pie" href="../english/index.htm">Homepage</a></li>
<li><a href="../english/lexilogos_introduction.htm" title="Introduction"><img src="../images/w_q.gif" class="img-0" alt="introduction"></a>
<a class="pie" href="../english/lexilogos_introduction.htm">Introduction</a></li>
<li><a href="../english/communication.htm" title="Support Lexilogos!"><img src="../images/w_cor.gif" class="img-0" alt="support"></a>
<a class="pie" href="../english/communication.htm">Donation</a></li>
</ul>
<div class="esp"></div>
<div class="center"><a class="co" href="../contact.php">Xavier Nègre &nbsp; © Lexilogos 2002-2025</a></div>
<div class="espd"></div>
</body>
</html>