<!doctype html>
<head>
<meta charset="utf-8">
<title>Test Greek alphabet</title>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style>
a.info{ text-decoration:none; cursor:help; color:#CC0033; font-size:2em; font-family:Times New Roman, Arial; }
a.info:hover { background-color:white;}
a.info .test-lettre{display: none; }
a.info:hover .test-lettre{ display:block; position:relative; top:0.2em; }
.test-a { color:#CC0033; font-family:Times New Roman, Arial; }
.test-b { color:#0000FF; font-family:Times New Roman, Arial; padding-left: 0.75em; }
.test-c { color:#999999; font-family:Times New Roman, Arial; padding-left: 0.75em; }
</style>
<script>
if (parent.frames.length < 1) { 
document.location.href = 'greek_letter.htm'; 
}
</script>
</head>
<body>
<div class="center">
<a href="javascript:location.reload()">Discover another letter</a>
<div class="espd"></div>

<a class="info" href="#">ο<div class="test-lettre"><span class="test-a">Ο ο</span> <span class="test-b">όμικρον</span> <span class="test-c">O</span> <span class="test-c">omicron</span></div></a> 
</div>
</body>
</html>