<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Japanese Online Keyboard: Kanji, Hiragana, Katakana • LEXILOGOS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Online keyboard to type a Japanese text with Kanji (classified by strokes, radicals ou pronunciation) and Kana characters: Hiragana, Katakana">
<meta name="Keywords" content="kanji,alphabet,japanese,keyboard">
<meta property="og:image" content="https://www.lexilogos.com/images/babel_bruegel.jpg">
<link rel="shortcut icon" href="../favicon.ico">
<style>
.cadr { width: 80%; color: #0000FF; font-family:MS UI Gothic; font-size:1.7em; padding: 3px; }
.bt, .bt:hover, .bt:visited { text-decoration: none; cursor: pointer; font-size:1em; font-family:MS UI Gothic; color: #CC0033; }
.casemain { text-align: center; margin-left: 10%; margin-right: 10%; }
.casetable { margin: auto; }
.case { display: inline-block; padding-right: 2em; padding-bottom: 1em; text-align: center; vertical-align: top; }
a.chi { color: #CC0033; text-decoration: none; font-size:1.8em; }
a.chi:hover { color: #0000FF; background-color: #FFFF7D; }
.tra { color: #CC0099; }
.cle { color: #339900; }
.pro { color: #999999; font-size:85%; font-family:Arial; }
.prob { color: #999999; font-size:80%; line-height: 80%; font-family:Arial; }

.tabl { margin:auto; }
.tabl tr { vertical-align:top; }
.tabl td:nth-child(1) { text-align:left; padding-right:6em; }
.tabl td:nth-child(2) { text-align:center; }
.tabl td:nth-child(3) { text-align:left; padding-left:3em; }

@media screen and (max-width:960px) { 
.tabl td {display:inline-block;}
.tabl td:nth-child(1) { padding-right:0.5em;}
.tabl td:nth-child(2) { text-align:left; }
.tabl td:nth-child(3) { padding-left:0.5em; }
.casemain { margin-left:0; margin-right:0; }
}
</style>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<script src="../code/carnikaji.js"></script>
<script src="../code/nikb.js"></script>
<script src="../code/clipboard.js"></script>
<script src="../code/savee.js"></script>
<!-- GA -->
</head>
<body onLoad="conversion.saisie.focus()">
<div class="ca"><a href="../english/new.htm"><img src="../images/lexilogos_papagai.gif" class="imgpap" title="What's new?" alt="new"></a></div>
<div class="cb"><a href="../english/index.htm"><img src="../images/lexilogos_english.gif" class="imgloge" title="Online Dictionaries &gt; Index" alt="Lexilogos"></a></div>
<div class="cc"><a href="index.htm"><img src="../images/keyboard.gif" class="imgclae" alt="online keyboard" title="Index languages"></a><br>
<span class="kb-t">Japanese</span> &nbsp; <span class="kb-niho">日本語</span></div>
<div class="cd"><a href="../english/communication.htm"><img src="../images/don_e.png" class="imgdone" title="Donate: Thank you!"></a><br>
<a href="../english/search.htm"><img src="../images/w_bouscateur.gif" class="imgbou" title="Search on Lexilogos &amp; on the web" alt="search"></a><br>
<a href="../clavier/nihongo.php"><img src="../images/fra.gif" class="imgflag" alt="French" title="in French / en français"></a> 
</div>
<div class="esp"></div>
<div class="ce"><a class="frp" href="hiragana.htm">Hiragana</a> &nbsp; <a class="frp" href="katakana.htm">Katakana</a> &nbsp; <a class="frp" href="../english/japanese_dictionary.htm">Japanese</a></div>
<div class="esp"></div>
<div class="center">
<form>
<select name="select" onChange="window.location=this.options[this.selectedIndex].value">
<option value="index.htm" selected>select a language</option>
<option value="ipa.htm">International Phonetic Alphabet</option>
<option value="latin_alphabet.htm">Latin script</option>
<option value="diacritics.htm">Diacritics</option>
<option value="albanian.htm">Albanian</option>
<option value="amharic.htm">Amharic</option>
<option value="arabic.htm">Arabic</option>
<option value="arabic_latin.htm">Arabic (Latin)</option>
<option value="arabian_north.htm">Arabian (Old North)</option>
<option value="arabian_south.htm">Arabian (Old South)</option>
<option value="armenian.htm">Armenian</option>
<option value="armenian_western.htm">Armenian (Western)</option>
<option value="azeri.htm">Azerbaijani</option>
<option value="bashkir.htm">Bashkir</option>
<option value="baybayin.htm">Baybayin</option>
<option value="belarusian.htm">Belarusian</option>
<option value="bengali.htm">Bengali</option>
<option value="tamazight_latin.htm">Berber (Latin)</option>
<option value="tamazight.htm">Berber (Tifinagh)</option>
<option value="bosnian.htm">Bosnian</option>
<option value="brahmi.htm">Brahmi</option>
<option value="bulgarian.htm">Bulgarian</option>
<option value="burmese.htm">Burmese</option>
<option value="catalan.htm">Catalan</option>
<option value="chechen.htm">Chechen</option>
<option value="tsalagi.htm">Cherokee</option>
<option value="chinese.php">Chinese</option>
<option value="chinese_pinyin.htm">Chinese Pinyin</option>
<option value="coptic.htm">Coptic</option>
<option value="croatian.htm">Croatian</option>
<option value="czech.htm">Czech</option>
<option value="danish.htm">Danish</option>
<option value="dutch.htm">Dutch</option>
<option value="hieroglyph.php">Egyptian (Ancient) Hieroglyphs</option>
<option value="egyptian_latin.htm">Egyptian (Ancient) (Latin)</option>
<option value="english.htm">English (Old)</option>
<option value="esperanto.htm">Esperanto</option>
<option value="estonian.htm">Estonian</option>
<option value="faroese.htm">Faroese</option>
<option value="finnish.htm">Finnish</option>
<option value="french.htm">French</option>
<option value="gaelic_irish.htm">Gaelic Irish</option>
<option value="gaelic_scottish.htm">Gaelic Scottish</option>
<option value="georgian.htm">Georgian</option>
<option value="german.htm">German</option>
<option value="glagolitic.htm">Glagolitic</option>
<option value="gothic.htm">Gothic</option>
<option value="grantha.htm">Grantha</option>
<option value="greek_ancient.htm">Greek (Ancient)</option>
<option value="greek_modern.htm">Greek (Modern)</option>
<option value="greek_latin.htm">Greek (Latin)</option>
<option value="gujarati.htm">Gujarati</option>
<option value="hausa.htm">Hausa</option>
<option value="hawaiian.htm">Hawaiian</option>
<option value="hebrew.htm">Hebrew</option>
<option value="hebrew_latin.htm">Hebrew (Latin)</option>
<option value="devanagari.htm">Hindi</option>
<option value="hungarian.htm">Hungarian</option>
<option value="icelandic.htm">Icelandic</option>
<option value="indo_european.htm">Indo-European</option>
<option value="ingush.htm">Ingush</option>
<option value="inuktitut.htm">Inuktitut</option>
<option value="italian.htm">Italian</option>
<option value="japanese.php">Japanese</option>
<option value="hiragana.htm">Japanese Hiragana</option>
<option value="katakana.htm">Japanese Katakana</option>
<option value="jawi.htm">Jawi</option>
<option value="kannada.htm">Kannada</option>
<option value="kashmiri.htm">Kashmiri</option>
<option value="kashubian.htm">Kashubian</option>
<option value="kazakh.htm">Kazakh</option>
<option value="khmer.htm">Khmer</option>
<option value="khowar.htm">Khowar</option>
<option value="korean.htm">Korean</option>
<option value="kurdish.htm">Kurdish</option>
<option value="kyrgyz.htm">Kyrgyz</option>
<option value="lao.htm">Lao</option>
<option value="latin.htm">Latin</option>
<option value="latvian.htm">Latvian</option>
<option value="lingala.htm">Lingala</option>
<option value="lithuanian.htm">Lithuanian</option>
<option value="macedonian.htm">Macedonian</option>
<option value="malayalam.htm">Malayalam</option>
<option value="thaana.htm">Maldivian</option>
<option value="maltese.htm">Maltese</option>
<option value="maori.htm">Maori</option>
<option value="meitei.htm">Meitei</option>
<option value="mongolian.htm">Mongolian</option>
<option value="montenegrin.htm">Montenegrin</option>
<option value="norwegian.htm">Norwegian</option>
<option value="odia.htm">Oriya</option>
<option value="pashto.htm">Pashto</option>
<option value="persian.htm">Persian</option>
<option value="persian_old.htm">Persian (Old)</option>
<option value="phoenician.htm">Phoenician</option>
<option value="polish.htm">Polish</option>
<option value="portuguese.htm">Portuguese</option>
<option value="gurmukhi.htm">Punjabi</option>
<option value="romanian.htm">Romanian</option>
<option value="futhark.htm">Runes Futhark</option>
<option value="futhark_old.htm">Runes Elder Futhark</option>
<option value="russian.htm">Russian</option>
<option value="samaritan.htm">Samaritan</option>
<option value="sanskrit_devanagari.htm">Sanskrit Devanagari</option>
<option value="sanskrit_devanagari_uttara.htm">Sanskrit Devanagari Uttara</option>
<option value="sanskrit_vedic.htm">Sanskrit Vedic</option>
<option value="sanskrit_latin.htm">Sanskrit (Latin)</option>
<option value="serbian.htm">Serbian</option>
<option value="serbian_latin.htm">Serbian (Latin)</option>
<option value="sindhi.htm">Sindhi</option>
<option value="sinhala.htm">Sinhala</option>
<option value="slovak.htm">Slovak</option>
<option value="slovenian.htm">Slovenian</option>
<option value="osmanya.htm">Somali Osmanya</option>
<option value="sorani.htm">Sorani</option>
<option value="spanish.htm">Spanish</option>
<option value="swedish.htm">Swedish</option>
<option value="syriac.htm">Syriac</option>
<option value="syriac_latin.htm">Syriac (Latin)</option>
<option value="tajik.htm">Tajik</option>
<option value="tamil.htm">Tamil</option>
<option value="tatar.htm">Tatar</option>
<option value="telugu.htm">Telugu</option>
<option value="thai.htm">Thai</option>
<option value="tibetan.htm">Tibetan</option>
<option value="tigrinya.htm">Tigrinya</option>
<option value="torwali.htm">Torwali</option>
<option value="turkish.htm">Turkish</option>
<option value="ottoman_turkish.htm">Turkish (Ottoman)</option>
<option value="turkmen.htm">Turkmen</option>
<option value="ukrainian.htm">Ukrainian</option>
<option value="urdu.htm">Urdu</option>
<option value="uyghur.htm">Uyghur</option>
<option value="uzbek.htm">Uzbek</option>
<option value="vietnamese.htm">Vietnamese</option>
<option value="welsh.htm">Welsh</option>
<option value="wolof.htm">Wolof</option>
<option value="yiddish.htm">Yiddish</option>
<option value="yoruba.htm">Yoruba</option>
</select>
</form>
<br>
<form name="conversion" action="" method="post">
<div class="delc">
<br>
 
<input type="button" class="eff" title="clear" onClick="effacer();conversion.saisie.focus()" value="">
</div>
<textarea spellcheck="false" name="saisie" id="bar" onKeyUp="transcrire()" rows="4" class="cadr" tabindex="1"></textarea>
<br>
<br>
<input type="button" class="bf" data-clipboard-action="copy" data-clipboard-target="#bar" value="copy">
<script>
var clipboard = new Clipboard('.bf');
clipboard.on('success', function(e) {
console.log(e); 
});
clipboard.on('error', function(e) {
console.log(e);
});
</script>
<input type="button" class="bf" onClick="save()" value="save">
<input type="button" class="bf" onClick="kb(' ')" value="space"><input type="button" onClick="conversion.saisie.rows=4;conversion.q.focus();" value="small frame" class="bf"><input type="button" onClick="conversion.saisie.rows=40;conversion.q.focus();" value="large frame" class="bf">
<br>
<br>
<table class="tabl">
<tr>
<td><p>
<input type="button" class="bt" onclick="kb('〜')" value="〜" title="波ダッシュ nami dasshu">
<input type="button" class="bt" onclick="kb('・')" value="・" title="中黒 nakaguro">
<input type="button" class="bt" onclick="kb('ー')" value="ー" title="長音符 chōonpu">
<input type="button" class="bt" onclick="kb('「')" value="「" title="鉤括弧 kagikakko">
<input type="button" class="bt" onclick="kb('」')" value="」" title="鉤括弧 kagikakko">
<input type="button" class="bt" onclick="kb('、')" value="、" title="読点 tōten">
<input type="button" class="bt" onclick="kb('。')" value="。" title="句点 kuten">
</p>
<p>
<input type="button" class="bt" onclick="kb('々')" value="々" title="踊り字 odoriji - repetition mark kanji">
<input type="button" class="bt" onclick="kb('ー')" value="ー" title="長音符 chōonpu - katakana long sound symbol">
<input type="button" class="bt" onclick="kb('ヽ')" value="ヽ" title="iteration mark katakana">
<input type="button" class="bt" onclick="kb('ヾ')" value="ヾ" title="iteration mark katakana with dakuten">
<input type="button" class="bt" onclick="kb('ゝ')" value="ゝ" title="iteration mark hiragana">
<input type="button" class="bt" onclick="kb('ゞ')" value="ゞ" title="iteration mark hiragana with dakuten">
</p>
</td>
<td> 
<p class="k">Type the beginning of the pronunciation of the Kanji:</p> 
<input name='q' onkeyup='verif()' size='30' maxlength='10' tabindex='2'>
</td>
<td>
<div class="boxdevb">
<p class="k tra">by stroke</p>
 <select name="traits" onChange='submit()' tabindex='3'>
<option>strokes</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
</select>
</div>
<span class="esps"></span>
<div class="boxdevb">
<p class="k cle">by radical</p>
<select name="cles" onChange='submit()' tabindex='4'>
<option>select a radical</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
<option value="32">32</option>
<option value="33">33</option>
<option value="34">34</option>
<option value="35">35</option>
<option value="36">36</option>
<option value="37">37</option>
<option value="38">38</option>
<option value="39">39</option>
<option value="40">40</option>
<option value="41">41</option>
<option value="42">42</option>
<option value="43">43</option>
<option value="44">44</option>
<option value="45">45</option>
<option value="46">46</option>
<option value="47">47</option>
<option value="48">48</option>
<option value="49">49</option>
<option value="50">50</option>
<option value="51">51</option>
<option value="52">52</option>
<option value="53">53</option>
<option value="54">54</option>
<option value="55">55</option>
<option value="56">56</option>
<option value="57">57</option>
<option value="58">58</option>
<option value="59">59</option>
<option value="60">60</option>
<option value="61">61</option>
<option value="62">62</option>
<option value="63">63</option>
<option value="64">64</option>
<option value="65">65</option>
<option value="66">66</option>
<option value="67">67</option>
<option value="68">68</option>
<option value="69">69</option>
<option value="70">70</option>
<option value="71">71</option>
<option value="72">72</option>
<option value="73">73</option>
<option value="74">74</option>
<option value="75">75</option>
<option value="76">76</option>
<option value="77">77</option>
<option value="78">78</option>
<option value="79">79</option>
<option value="80">80</option>
<option value="81">81</option>
<option value="82">82</option>
<option value="83">83</option>
<option value="84">84</option>
<option value="85">85</option>
<option value="86">86</option>
<option value="87">87</option>
<option value="88">88</option>
<option value="89">89</option>
<option value="90">90</option>
<option value="91">91</option>
<option value="92">92</option>
<option value="93">93</option>
<option value="94">94</option>
<option value="95">95</option>
<option value="96">96</option>
<option value="97">97</option>
<option value="98">98</option>
<option value="99">99</option>
<option value="100">100</option>
<option value="101">101</option>
<option value="102">102</option>
<option value="103">103</option>
<option value="104">104</option>
<option value="105">105</option>
<option value="106">106</option>
<option value="107">107</option>
<option value="108">108</option>
<option value="109">109</option>
<option value="110">110</option>
<option value="111">111</option>
<option value="112">112</option>
<option value="113">113</option>
<option value="114">114</option>
<option value="115">115</option>
<option value="116">116</option>
<option value="117">117</option>
<option value="118">118</option>
<option value="119">119</option>
<option value="120">120</option>
<option value="121">121</option>
<option value="122">122</option>
<option value="123">123</option>
<option value="124">124</option>
<option value="125">125</option>
<option value="126">126</option>
<option value="127">127</option>
<option value="128">128</option>
<option value="129">129</option>
<option value="130">130</option>
<option value="131">131</option>
<option value="132">132</option>
<option value="133">133</option>
<option value="134">134</option>
<option value="135">135</option>
<option value="136">136</option>
<option value="137">137</option>
<option value="138">138</option>
<option value="139">139</option>
<option value="140">140</option>
<option value="141">141</option>
<option value="142">142</option>
<option value="143">143</option>
<option value="144">144</option>
<option value="145">145</option>
<option value="146">146</option>
<option value="147">147</option>
<option value="148">148</option>
<option value="149">149</option>
<option value="150">150</option>
<option value="151">151</option>
<option value="152">152</option>
<option value="153">153</option>
<option value="154">154</option>
<option value="155">155</option>
<option value="156">156</option>
<option value="157">157</option>
<option value="158">158</option>
<option value="159">159</option>
<option value="160">160</option>
<option value="161">161</option>
<option value="162">162</option>
<option value="163">163</option>
<option value="164">164</option>
<option value="165">165</option>
<option value="166">166</option>
<option value="167">167</option>
<option value="168">168</option>
<option value="169">169</option>
<option value="170">170</option>
<option value="171">171</option>
<option value="172">172</option>
<option value="173">173</option>
<option value="174">174</option>
<option value="175">175</option>
<option value="176">176</option>
<option value="177">177</option>
<option value="178">178</option>
<option value="179">179</option>
<option value="180">180</option>
<option value="181">181</option>
<option value="182">182</option>
<option value="183">183</option>
<option value="184">184</option>
<option value="185">185</option>
<option value="186">186</option>
<option value="187">187</option>
<option value="188">188</option>
<option value="189">189</option>
<option value="190">190</option>
<option value="191">191</option>
<option value="192">192</option>
<option value="193">193</option>
<option value="194">194</option>
<option value="195">195</option>
<option value="196">196</option>
<option value="197">197</option>
<option value="198">198</option>
<option value="199">199</option>
<option value="200">200</option>
<option value="201">201</option>
<option value="202">202</option>
<option value="203">203</option>
<option value="204">204</option>
<option value="205">205</option>
<option value="206">206</option>
<option value="207">207</option>
<option value="208">208</option>
<option value="209">209</option>
<option value="210">210</option>
<option value="211">211</option>
<option value="212">212</option>
<option value="213">213</option>
<option value="214">214</option>
</select>
</div>
</td>
</tr>
</table>
</form>
<div class="espc"></div>
 	
</div>
<div class="espb"></div>
<div class="pa"><b>Instructions</b>
<p>1) Type the beginning of the pronunciation of the Kanji in Latin characters </p>
<p>2) Type a space key (or <i>Submit</i>) </p>
<p>3) Select the Kanji with a mouse click </p>
<ul>
<li> To get <a class="lia" href="hiragana.htm">Hiragana</a> characters, type a syllable in the frame in Latin alphabet in lower case letters</li>
<li> To get <a class="lia" href="katakana.htm">Katakana</a> characters, type a syllable in the frame in Latin alphabet in UPPER case letters</li>
<li> Type = to get a small kana: a=, i=, u=, e=, o= &amp; tsu= (or q)</li>
<li> Type the circumflex accent (â, Â) for the long vowels or, for the katakana, type the underscore _ after the vowel</li>
</ul>
<br>
Copy [Ctrl]+[C] &amp; Paste [Ctrl]+[V] 
</div>
<div class="espa"></div>
<p class="pp"><span class="ji">&#x2192;</span> <a href="hiragana.htm">Hiragana keyboard</a> </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="katakana.htm">Katakana keyboard</a> </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="chinese.php">Chinese keyboard</a> </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="../english/japanese_dictionary.htm">Japanese language</a>: dictionary, pronunciation, grammar </p>
<p class="pp"><span class="ji">&#x2192;</span> <a href="index.htm">Multilingual keyboard</a>: index </p>

<div class="espb"></div>
<ul class="nav">
<li><a href="../english/contact.php" title="Share your feedback"><img src="../images/w_enveloppe.gif" class="img-0" alt="contact"></a>
<a class="pie" href="../english/contact.php">Contact</a></li>
<li><a href="../english/search.htm" title="Search on Lexilogos &amp; on the web"><img src="../images/w_bouscateur.gif" class="img-0" alt="search"></a> 
<a class="pie" href="../english/search.htm">Search</a></li>
<li><a title="updates" class="new" href="../english/new.htm">NEW</a>
<a class="pie" href="../english/new.htm">What's new?</a> </li>
<li><a href="../english/index.htm" title="Homepage"><img src="../images/w_accueil.gif" class="img-0" alt="homepage"></a>
<a class="pie" href="../english/index.htm">Homepage</a></li>
<li><a href="../english/lexilogos_introduction.htm" title="Introduction"><img src="../images/w_q.gif" class="img-0" alt="introduction"></a>
<a class="pie" href="../english/lexilogos_introduction.htm">Introduction</a></li>
<li><a href="../english/communication.htm" title="Support Lexilogos!"><img src="../images/w_cor.gif" class="img-0" alt="support"></a>
<a class="pie" href="../english/communication.htm">Donation</a></li>
</ul>
<div class="esp"></div>
<div class="center"><a class="co" href="../contact.php">Xavier Nègre &nbsp; © Lexilogos 2002-2025</a></div>
<div class="espd"></div>
</body>
</html>
