<!doctype html>
<head>
<meta charset="utf-8">
<title>Arabic Alphabet Online Test</title>
<link href="../css/style.css" rel="stylesheet" type="text/css">
<style>
a.info{ text-decoration:none; cursor:help; color:#CC0033; font-size:3em; font-family:Times New Roman, Arial; }
a.info:hover { background-color:white;}
a.info .test-lettre{display: none; }
a.info:hover .test-lettre{ display:block; position:relative; top:0.2em; }
.test-a { color:#0000FF; font-family:Simplified Arabic, Times New Roman, Arial; }
.test-b { color:#A8A8FF; font-family:Simplified Arabic, Times New Roman, Arial; }
.test-n { color:#999999; font-family: Arial; font-size:50%; }
</style>
<script>
if (parent.frames.length < 1) { 
document.location.href = 'arabic_letter.htm'; 
}
</script>
</head>
<body>
<div class="center">
<a href="javascript:location.reload()">Discover another letter</a>
<div class="espd"></div>
<a class="info" href="#">&#65215;<div class="test-lettre"><span class="test-a">&#65213;</span> &nbsp; <span class="test-n">ḍad</span> &nbsp; <span class="test-a">&#65215;<span class="test-b">&#1600;</span><span class="test-b">&#1600;</span>&#65216;<span class="test-b">&#1600;</span><span class="test-b">&#1600;</span>&#65214;</span></div></a> 
</div>
</body>
</html>